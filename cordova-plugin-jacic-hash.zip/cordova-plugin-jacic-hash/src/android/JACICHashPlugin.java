package jp.ne.datt.plugin;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaPlugin;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * JACIC Hash Cordova Plugin for Android
 * Wrapper for JACIC Hash native library
 */
public class JACICHashPlugin extends CordovaPlugin {

    // Load native library
    static {
        System.loadLibrary("jacic-hash-lib");
    }

    // Native method
    private native int nativeWriteHash(String sourceFilePath, String destFilePath);

    @Override
    public boolean execute(String action, JSONArray args, CallbackContext callbackContext) throws JSONException {
        if ("writeHash".equals(action)) {
            String sourceFilePath = args.getString(0);
            String destFilePath = args.getString(1);
            writeHash(sourceFilePath, destFilePath, callbackContext);
            return true;
        }
        return false;
    }

    /**
     * Write hash value to JPEG file
     */
    private void writeHash(final String sourceFilePath, final String destFilePath, final CallbackContext callbackContext) {
        cordova.getThreadPool().execute(new Runnable() {
            @Override
            public void run() {
                try {
                    // Validate parameters
                    if (sourceFilePath == null || sourceFilePath.isEmpty() ||
                        destFilePath == null || destFilePath.isEmpty()) {
                        JSONObject error = new JSONObject();
                        error.put("code", -101);
                        error.put("message", "Invalid parameters: sourceFilePath and destFilePath are required");
                        callbackContext.error(error);
                        return;
                    }

                    // Call native method
                    int result = nativeWriteHash(sourceFilePath, destFilePath);

                    // Return result
                    JSONObject response = new JSONObject();
                    response.put("code", result);

                    if (result == 0) {
                        response.put("message", "Hash value written successfully");
                        response.put("outputPath", destFilePath);
                        callbackContext.success(response);
                    } else {
                        response.put("message", getErrorMessage(result));
                        response.put("sourcePath", sourceFilePath);
                        response.put("destPath", destFilePath);
                        callbackContext.error(response);
                    }
                } catch (JSONException e) {
                    callbackContext.error("JSON error: " + e.getMessage());
                }
            }
        });
    }

    /**
     * Get error message for writeHash error codes
     */
    private String getErrorMessage(int errorCode) {
        switch (errorCode) {
            case -101: return "Incorrect parameter";
            case -102: return "Same file path for source and destination";
            case -201: return "Source file does not exist";
            case -202: return "Destination file already exists";
            case -203: return "Failed to open file";
            case -204: return "File size is zero";
            case -205: return "Failed to write file";
            case -206: return "Failed to close file";
            case -301: return "Incorrect EXIF format";
            case -302: return "APP5 segment already exists";
            case -307: return "Date information not found";
            case -900: return "Other error";
            default: return "Unknown error (code: " + errorCode + ")";
        }
    }
}
