#include <jni.h>
#include <string>
#include "JACICHashLib/writeHashLib.h"

extern "C" {

/**
 * Write hash value to JPEG file
 * JNI wrapper for JACIC_WriteHashValue
 */
JNIEXPORT jint JNICALL
Java_jp_ne_datt_plugin_JACICHashPlugin_nativeWriteHash(
        JNIEnv *env,
        jobject /* this */,
        jstring sourceFilePath,
        jstring destFilePath) {

    const char *srcPath = env->GetStringUTFChars(sourceFilePath, nullptr);
    const char *dstPath = env->GetStringUTFChars(destFilePath, nullptr);

    int result = JACIC_WriteHashValue(srcPath, dstPath);

    env->ReleaseStringUTFChars(sourceFilePath, srcPath);
    env->ReleaseStringUTFChars(destFilePath, dstPath);

    return result;
}

/**
 * Check hash value in JPEG file
 * JNI wrapper for JACIC_CheckHashValue
 */
JNIEXPORT jint JNICALL
Java_jp_ne_datt_plugin_JACICHashPlugin_nativeCheckHash(
        JNIEnv *env,
        jobject /* this */,
        jstring checkFilePath) {

    const char *checkPath = env->GetStringUTFChars(checkFilePath, nullptr);

    int result = JACIC_CheckHashValue(checkPath);

    env->ReleaseStringUTFChars(checkFilePath, checkPath);

    return result;
}

} // extern "C"
