# cordova-plugin-jacic-hash

Cordova plugin for embedding hash values in JPEG APP5 region.

## Installation

### From local path

```bash
cordova plugin add /path/to/cordova-plugin-jacic-hash
```

### For Monaca

```bash
monaca plugin add ../cordova-plugin-jacic-hash
```

## Supported Platforms

- iOS (11.0+)
- Android (API Level 21+)

## API

### writeHash

Embed hash value into JPEG file.

```javascript
JACICHash.writeHash(sourceFilePath, destFilePath, successCallback, errorCallback);
```

**Parameters:**
- `sourceFilePath` (String): Source JPEG file path
- `destFilePath` (String): Destination JPEG file path
- `successCallback` (Function): Success callback
- `errorCallback` (Function): Error callback

**Success response:**
```javascript
{
  code: 0,
  message: "Hash value written successfully",
  outputPath: "/path/to/output.jpg"
}
```

**Error codes:**
- `-101`: Incorrect parameter
- `-102`: Same file path for source and destination
- `-201`: Source file does not exist
- `-202`: Destination file already exists
- `-203`: Failed to open file
- `-204`: File size is zero
- `-205`: Failed to write file
- `-206`: Failed to close file
- `-301`: Incorrect EXIF format
- `-302`: APP5 segment already exists
- `-307`: Date information not found
- `-900`: Other error

## Example

```javascript
document.addEventListener('deviceready', function() {
    // Write hash
    JACICHash.writeHash(
        '/path/to/source.jpg',
        '/path/to/output.jpg',
        function(result) {
            console.log('Success:', result.message);
            console.log('Output:', result.outputPath);
        },
        function(error) {
            console.error('Error:', error.message);
        }
    );
});
```

## Dependencies

- cordova-plugin-file (for file system access)

## License

Apache 2.0

## Author

DATT JAPAN Inc.
